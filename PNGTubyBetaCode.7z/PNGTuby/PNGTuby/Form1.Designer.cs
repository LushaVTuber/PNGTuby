﻿
namespace PNGTuby
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.veryhappy = new System.Windows.Forms.Button();
            this.neutral = new System.Windows.Forms.Button();
            this.happy = new System.Windows.Forms.Button();
            this.angry = new System.Windows.Forms.Button();
            this.shocked = new System.Windows.Forms.Button();
            this.sad = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.CharacterImage = new System.Windows.Forms.PictureBox();
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.label3 = new System.Windows.Forms.Label();
            this.VolumeBar = new System.Windows.Forms.ProgressBar();
            this.label4 = new System.Windows.Forms.Label();
            this.VolumeTrack = new System.Windows.Forms.TrackBar();
            this.label5 = new System.Windows.Forms.Label();
            this.DeviceBox = new System.Windows.Forms.ComboBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.KeyBind1 = new System.Windows.Forms.Button();
            this.KeyBind2 = new System.Windows.Forms.Button();
            this.KeyBind3 = new System.Windows.Forms.Button();
            this.KeyBind4 = new System.Windows.Forms.Button();
            this.Keybind5 = new System.Windows.Forms.Button();
            this.KeyBind6 = new System.Windows.Forms.Button();
            this.KeyBind0 = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.ReadyButton = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.UpdateSetLabel = new System.Windows.Forms.Label();
            this.UpdateSetBar = new System.Windows.Forms.TrackBar();
            ((System.ComponentModel.ISupportInitialize)(this.CharacterImage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.VolumeTrack)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.UpdateSetBar)).BeginInit();
            this.SuspendLayout();
            // 
            // veryhappy
            // 
            resources.ApplyResources(this.veryhappy, "veryhappy");
            this.veryhappy.Name = "veryhappy";
            this.veryhappy.UseVisualStyleBackColor = true;
            this.veryhappy.Click += new System.EventHandler(this.VeryHappy_Click);
            // 
            // neutral
            // 
            resources.ApplyResources(this.neutral, "neutral");
            this.neutral.Name = "neutral";
            this.neutral.UseVisualStyleBackColor = true;
            this.neutral.Click += new System.EventHandler(this.Neutral_Click);
            // 
            // happy
            // 
            resources.ApplyResources(this.happy, "happy");
            this.happy.Name = "happy";
            this.happy.UseVisualStyleBackColor = true;
            this.happy.Click += new System.EventHandler(this.Happy_Click);
            // 
            // angry
            // 
            resources.ApplyResources(this.angry, "angry");
            this.angry.Name = "angry";
            this.angry.UseVisualStyleBackColor = true;
            this.angry.Click += new System.EventHandler(this.Angry_Click);
            // 
            // shocked
            // 
            resources.ApplyResources(this.shocked, "shocked");
            this.shocked.Name = "shocked";
            this.shocked.UseVisualStyleBackColor = true;
            this.shocked.Click += new System.EventHandler(this.Shocked_Click);
            // 
            // sad
            // 
            resources.ApplyResources(this.sad, "sad");
            this.sad.Name = "sad";
            this.sad.UseVisualStyleBackColor = true;
            this.sad.Click += new System.EventHandler(this.Sad_Click);
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.Name = "label1";
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.Name = "label2";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // CharacterImage
            // 
            this.CharacterImage.BackColor = System.Drawing.SystemColors.Control;
            resources.ApplyResources(this.CharacterImage, "CharacterImage");
            this.CharacterImage.Name = "CharacterImage";
            this.CharacterImage.TabStop = false;
            this.CharacterImage.Click += new System.EventHandler(this.CharachterImage_Click);
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.Name = "label3";
            // 
            // VolumeBar
            // 
            resources.ApplyResources(this.VolumeBar, "VolumeBar");
            this.VolumeBar.Name = "VolumeBar";
            // 
            // label4
            // 
            resources.ApplyResources(this.label4, "label4");
            this.label4.Name = "label4";
            // 
            // VolumeTrack
            // 
            this.VolumeTrack.LargeChange = 10;
            resources.ApplyResources(this.VolumeTrack, "VolumeTrack");
            this.VolumeTrack.Maximum = 100;
            this.VolumeTrack.Name = "VolumeTrack";
            this.VolumeTrack.SmallChange = 5;
            this.VolumeTrack.ValueChanged += new System.EventHandler(this.VolumeTrack_ValueChanged);
            // 
            // label5
            // 
            resources.ApplyResources(this.label5, "label5");
            this.label5.Name = "label5";
            // 
            // DeviceBox
            // 
            this.DeviceBox.FormattingEnabled = true;
            resources.ApplyResources(this.DeviceBox, "DeviceBox");
            this.DeviceBox.Name = "DeviceBox";
            // 
            // checkBox1
            // 
            resources.ApplyResources(this.checkBox1, "checkBox1");
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // KeyBind1
            // 
            resources.ApplyResources(this.KeyBind1, "KeyBind1");
            this.KeyBind1.Name = "KeyBind1";
            this.KeyBind1.UseVisualStyleBackColor = true;
            this.KeyBind1.Click += new System.EventHandler(this.KeyBind1_Click);
            // 
            // KeyBind2
            // 
            resources.ApplyResources(this.KeyBind2, "KeyBind2");
            this.KeyBind2.Name = "KeyBind2";
            this.KeyBind2.UseVisualStyleBackColor = true;
            this.KeyBind2.Click += new System.EventHandler(this.KeyBind2_Click);
            // 
            // KeyBind3
            // 
            resources.ApplyResources(this.KeyBind3, "KeyBind3");
            this.KeyBind3.Name = "KeyBind3";
            this.KeyBind3.UseVisualStyleBackColor = true;
            this.KeyBind3.Click += new System.EventHandler(this.KeyBind3_Click);
            // 
            // KeyBind4
            // 
            resources.ApplyResources(this.KeyBind4, "KeyBind4");
            this.KeyBind4.Name = "KeyBind4";
            this.KeyBind4.UseVisualStyleBackColor = true;
            this.KeyBind4.Click += new System.EventHandler(this.KeyBind4_Click);
            // 
            // Keybind5
            // 
            resources.ApplyResources(this.Keybind5, "Keybind5");
            this.Keybind5.Name = "Keybind5";
            this.Keybind5.UseVisualStyleBackColor = true;
            this.Keybind5.Click += new System.EventHandler(this.Keybind5_Click);
            // 
            // KeyBind6
            // 
            resources.ApplyResources(this.KeyBind6, "KeyBind6");
            this.KeyBind6.Name = "KeyBind6";
            this.KeyBind6.UseVisualStyleBackColor = true;
            this.KeyBind6.Click += new System.EventHandler(this.KeyBind6_Click);
            // 
            // KeyBind0
            // 
            resources.ApplyResources(this.KeyBind0, "KeyBind0");
            this.KeyBind0.Name = "KeyBind0";
            this.KeyBind0.UseVisualStyleBackColor = true;
            this.KeyBind0.Click += new System.EventHandler(this.KeyBindGreenscreen_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            resources.GetString("comboBox1.Items"),
            resources.GetString("comboBox1.Items1"),
            resources.GetString("comboBox1.Items2")});
            resources.ApplyResources(this.comboBox1, "comboBox1");
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label6
            // 
            resources.ApplyResources(this.label6, "label6");
            this.label6.Name = "label6";
            // 
            // ReadyButton
            // 
            resources.ApplyResources(this.ReadyButton, "ReadyButton");
            this.ReadyButton.Name = "ReadyButton";
            this.ReadyButton.UseVisualStyleBackColor = true;
            this.ReadyButton.Click += new System.EventHandler(this.button1_Click);
            // 
            // label7
            // 
            resources.ApplyResources(this.label7, "label7");
            this.label7.Name = "label7";
            // 
            // UpdateSetLabel
            // 
            resources.ApplyResources(this.UpdateSetLabel, "UpdateSetLabel");
            this.UpdateSetLabel.Name = "UpdateSetLabel";
            // 
            // UpdateSetBar
            // 
            this.UpdateSetBar.LargeChange = 10;
            resources.ApplyResources(this.UpdateSetBar, "UpdateSetBar");
            this.UpdateSetBar.Maximum = 90;
            this.UpdateSetBar.Name = "UpdateSetBar";
            this.UpdateSetBar.SmallChange = 5;
            this.UpdateSetBar.Value = 15;
            this.UpdateSetBar.ValueChanged += new System.EventHandler(this.UpdateSetBar_ValueChanged);
            // 
            // Form1
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.UpdateSetBar);
            this.Controls.Add(this.UpdateSetLabel);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.ReadyButton);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.KeyBind0);
            this.Controls.Add(this.KeyBind6);
            this.Controls.Add(this.Keybind5);
            this.Controls.Add(this.KeyBind4);
            this.Controls.Add(this.KeyBind3);
            this.Controls.Add(this.KeyBind2);
            this.Controls.Add(this.KeyBind1);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.DeviceBox);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.VolumeTrack);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.VolumeBar);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.CharacterImage);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.sad);
            this.Controls.Add(this.shocked);
            this.Controls.Add(this.angry);
            this.Controls.Add(this.happy);
            this.Controls.Add(this.neutral);
            this.Controls.Add(this.veryhappy);
            this.KeyPreview = true;
            this.Name = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.CharacterImage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.VolumeTrack)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.UpdateSetBar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button veryhappy;
        private System.Windows.Forms.Button neutral;
        private System.Windows.Forms.Button happy;
        private System.Windows.Forms.Button angry;
        private System.Windows.Forms.Button shocked;
        private System.Windows.Forms.Button sad;
        private System.Windows.Forms.TrackBar UpdateSetBar;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        public System.Windows.Forms.PictureBox CharacterImage;
        private System.Windows.Forms.Timer timer;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ProgressBar VolumeBar;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TrackBar VolumeTrack;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox DeviceBox;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Button KeyBind1;
        private System.Windows.Forms.Button KeyBind2;
        private System.Windows.Forms.Button KeyBind3;
        private System.Windows.Forms.Button KeyBind4;
        private System.Windows.Forms.Button Keybind5;
        private System.Windows.Forms.Button KeyBind6;
        private System.Windows.Forms.Button KeyBind0;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button ReadyButton;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label UpdateSetLabel;
    }
}

