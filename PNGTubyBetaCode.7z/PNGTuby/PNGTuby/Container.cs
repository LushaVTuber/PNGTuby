﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PNGTuby
{
    static class Container
    {
        //exit variable
        public static bool Exit = false;

        //realtime measurement variables
        public static NAudio.CoreAudioApi.MMDevice SoundInputDevice;
        public static int Expression = 0;
        public static bool MouthOpen = false;
        public static int Volume = 0;
        public static int VolumeCompare = 0;

        public static int UpdateTime = 50;

        //image variables
        public static int[] ImageCount = new int[6];
        public static bool[] ImageCountReached = new bool[6];
        public static bool[] ImageHasAnimation = new bool[6];

        //background variables
        public static int[] BackImageCount = new int[6];
        public static bool[] BackImageCountReached = new bool[6];
        public static bool[] BackImageHasAnimation = new bool[6];
        public static bool[] BackImageHasCustom = new bool[6];

        public static Color BackColor = Color.Lime;
        public static bool GreenScreenOn;

        //hotkey variables
        public static int[] KeyBinds = new int[7];
        public static Keys[] valuesAsArray = (Keys[])Enum.GetValues(typeof(Keys));
        public static bool[] HotkeyRegistered = new bool[7];

        public static int KeyBindButtonPressed = -1;
    }
}
