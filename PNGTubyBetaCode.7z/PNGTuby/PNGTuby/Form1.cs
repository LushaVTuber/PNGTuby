﻿using NAudio.CoreAudioApi;
using System;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace PNGTuby
{
    public partial class Form1 : Form
    {
        //import the RegisterHotKey aqnd UnregisterHotkey methods
        [DllImport("user32.dll")]
        public static extern bool RegisterHotKey(IntPtr hWnd, int id, int fsModifiers, int vlc);
        [DllImport("user32.dll")]
        public static extern bool UnregisterHotKey(IntPtr hWnd, int id);


        //initialize local image variables
        public static int AnimationFrame = 0;
        public static int LastExpression = 0;
        public static bool LastTalkingState = false;

        public static int BackgroundAnimationFrame = 0;
        public static bool GreenScreenWasOn = false;


        public Form1()
        {
            InitializeComponent();


            //load the previously determined keybinds
            for (int i = 0; i < 173; i++)
            {
                for (int j = 0; j < 7; j++)
                {
                    if (PNGTuby.Container.KeyBinds[j] == i)
                    {
                        RegisterHotKey(this.Handle, i, 0x0000, i);

                        string Temp = "";
                        foreach (Keys valuesAsArrayCurrent in PNGTuby.Container.valuesAsArray)
                        {
                            if (i == (int)valuesAsArrayCurrent)
                            {
                                Temp = valuesAsArrayCurrent.ToString();
                                break;
                            }
                        }

                        switch (j)
                        {
                            case 0:
                                KeyBind0.Text = ("Keybind: " + Temp);

                                break;
                            case 1:
                                KeyBind1.Text = ("Keybind: " + Temp);

                                break;
                            case 2:
                                KeyBind2.Text = ("Keybind: " + Temp);

                                break;
                            case 3:
                                KeyBind3.Text = ("Keybind: " + Temp);

                                break;
                            case 4:
                                KeyBind4.Text = ("Keybind: " + Temp);

                                break;
                            case 5:
                                Keybind5.Text = ("Keybind: " + Temp);

                                break;
                            case 6:
                                KeyBind6.Text = ("Keybind: " + Temp);

                                break;
                            default:
                                break;
                        }
                    }
                }
            }

            //set the BackColor
            CharacterImage.BackColor = PNGTuby.Container.BackColor;

            //set up the sliders
            UpdateSetBar.Value = (PNGTuby.Container.UpdateTime / 2) - 10;
            VolumeTrack.Value = PNGTuby.Container.VolumeCompare;


            //set the first background and sprite
            if (PNGTuby.Container.BackImageHasCustom[PNGTuby.Container.Expression] == true)
            {
                CharacterImage.BackgroundImage = Image.FromFile("../Images/Background" + PNGTuby.Container.Expression + "/0.png");
            }
            else
            {
                CharacterImage.BackgroundImage = Image.FromFile("../Images/Background.png");
            }

            CharacterImage.Image = Image.FromFile("../Images/0/_.png");

            //setting up the audio shizz
            MMDeviceEnumerator en = new MMDeviceEnumerator();
            var devices = en.EnumerateAudioEndPoints(DataFlow.All, DeviceState.Active);
            DeviceBox.Items.AddRange(devices.ToArray());

            //timer stuff
            timer.Interval = 50;
            timer.Start();

            timer.Tick += Timer_Tick;

            //start things
            timer.Start();
        }


        //----------------------------------------------------------------------------------------------------------------
        //Ths portion of the code handles setting keybinds (when the flag for it is set), as well as responding to pressed keybinds
        //----------------------------------------------------------------------------------------------------------------
        protected override void WndProc(ref Message m)
        {

            // Catch when a HotKey is pressed
            if (m.Msg == 0x0312)
            {
                int id = m.WParam.ToInt32();


                if (id == PNGTuby.Container.KeyBinds[0])
                {
                    if (checkBox1.Checked == false)
                    {
                        checkBox1.Checked = true;
                        PNGTuby.Container.GreenScreenOn = true;
                    }
                    else
                    {
                        checkBox1.Checked = false;
                        PNGTuby.Container.GreenScreenOn = false;
                    }
                }
                else if (id == PNGTuby.Container.KeyBinds[1])
                {
                    neutral.PerformClick();
                }
                else if (id == PNGTuby.Container.KeyBinds[2])
                {
                    happy.PerformClick();
                }
                else if (id == PNGTuby.Container.KeyBinds[3])
                {
                    veryhappy.PerformClick();
                }
                else if (id == PNGTuby.Container.KeyBinds[4])
                {
                    angry.PerformClick();
                }
                else if (id == PNGTuby.Container.KeyBinds[5])
                {
                    shocked.PerformClick();
                }
                else if (id == PNGTuby.Container.KeyBinds[6])
                {
                    sad.PerformClick();
                }


                //check whether one of the possible keys is being pressed
                if (PNGTuby.Container.KeyBindButtonPressed != -1)
                {
                    for (int i = 0; i < 173; i++)
                    {
                        string Temp = "";
                        foreach (Keys valuesAsArrayCurrent in PNGTuby.Container.valuesAsArray)
                        {
                            if (i == (int)valuesAsArrayCurrent)
                            {
                                Temp = valuesAsArrayCurrent.ToString();
                                break;
                            }
                        }

                        if (id == i)
                        {
                            //check what key needs to be assigned, then assign it
                            switch (PNGTuby.Container.KeyBindButtonPressed)
                            {
                                case 0:
                                    PNGTuby.Container.KeyBinds[0] = i;
                                    KeyBind0.Text = ("Keybind: " + Temp);
                                    PNGTuby.Container.KeyBindButtonPressed = -1;

                                    break;
                                case 1:
                                    PNGTuby.Container.KeyBinds[1] = i;
                                    KeyBind1.Text = ("Keybind: " + Temp);
                                    PNGTuby.Container.KeyBindButtonPressed = -1;

                                    break;
                                case 2:
                                    PNGTuby.Container.KeyBinds[2] = i;
                                    KeyBind2.Text = ("Keybind: " + Temp);
                                    PNGTuby.Container.KeyBindButtonPressed = -1;

                                    break;
                                case 3:
                                    PNGTuby.Container.KeyBinds[3] = i;
                                    KeyBind3.Text = ("Keybind: " + Temp);
                                    PNGTuby.Container.KeyBindButtonPressed = -1;

                                    break;
                                case 4:
                                    PNGTuby.Container.KeyBinds[4] = i;
                                    KeyBind4.Text = ("Keybind: " + Temp);
                                    PNGTuby.Container.KeyBindButtonPressed = -1;

                                    break;
                                case 5:
                                    PNGTuby.Container.KeyBinds[5] = i;
                                    Keybind5.Text = ("Keybind: " + Temp);
                                    PNGTuby.Container.KeyBindButtonPressed = -1;

                                    break;
                                case 6:
                                    PNGTuby.Container.KeyBinds[6] = i;
                                    KeyBind6.Text = ("Keybind: " + Temp);
                                    PNGTuby.Container.KeyBindButtonPressed = -1;

                                    break;
                                default:
                                    break;
                            }
                        }
                    }

                    for (int i = 0; i < 173; i++)
                    {
                        bool KeybindExists = false;
                        for (int j = 0; j < 7; j++)
                        {
                            if (PNGTuby.Container.KeyBinds[j] == i)
                            {
                                KeybindExists = true;
                            }
                        }

                        if (KeybindExists == false)
                        {
                            UnregisterHotKey(this.Handle, i);
                        }
                    }
                    
                }
            }

            base.WndProc(ref m);
        }

        public void RegisterKeys()
        {
            for (int i = 0; i < 173; i++)
            {
                RegisterHotKey
                (
                    this.Handle, i, 0x0000, i
                );

            }
        }



        //----------------------------------------------------------------------------------------------------------------
        //Timer stuff ----------------------------------------------------------------------------------------------------
        //----------------------------------------------------------------------------------------------------------------
        public void Timer_Tick(object sender, EventArgs e)
        {

            //reset LastTalkState
            LastTalkingState = PNGTuby.Container.MouthOpen;

            //check mic selection and set volume
            if (DeviceBox.SelectedItem != null)
            {
                PNGTuby.Container.SoundInputDevice = (MMDevice)DeviceBox.SelectedItem;
                PNGTuby.Container.Volume = (int)(PNGTuby.Container.SoundInputDevice.AudioMeterInformation.MasterPeakValue * 100);

                VolumeBar.Value = PNGTuby.Container.Volume;
            }


            //-------------------------------------------------------------------------------------------------


            //check talking state
            if (PNGTuby.Container.Volume > PNGTuby.Container.VolumeCompare)
            {
                PNGTuby.Container.MouthOpen = true;
            }
            else
            {
                PNGTuby.Container.MouthOpen = false;
            }


            //-------------------------------------------------------------------------------------------------


            //update the background image, if necessary
            if (PNGTuby.Container.GreenScreenOn == true)
            {
                CharacterImage.BackgroundImage = null;
            }
            else
            {
                if (PNGTuby.Container.Expression != LastExpression || CharacterImage.BackgroundImage == null)
                {
                    //reset BackgroundAnimationFrame
                    BackgroundAnimationFrame = 0;

                    if (PNGTuby.Container.BackImageHasCustom[PNGTuby.Container.Expression] == true)
                    {
                        CharacterImage.BackgroundImage = Image.FromFile("../Images/Background" + PNGTuby.Container.Expression + "/0.png");
                    }
                    else
                    {
                        CharacterImage.BackgroundImage = Image.FromFile("../Images/Background.png");
                    }
                }
                else if (PNGTuby.Container.BackImageHasAnimation[PNGTuby.Container.Expression] == true)
                {
                    CharacterImage.BackgroundImage = Image.FromFile("../Images/Background" + PNGTuby.Container.Expression + "/" + BackgroundAnimationFrame + ".png");

                    if (BackgroundAnimationFrame < PNGTuby.Container.BackImageCount[PNGTuby.Container.Expression] - 1)
                    {
                        BackgroundAnimationFrame++;
                    }
                    else
                    {
                        BackgroundAnimationFrame = 0;
                    }
                }
            }
            

            //-------------------------------------------------------------------------------------------------


            //update CharacterImage, if necessary
            if (PNGTuby.Container.Expression != LastExpression || PNGTuby.Container.MouthOpen != LastTalkingState)
            {
                //reset LastExpression and AnimationFrame
                LastExpression = PNGTuby.Container.Expression;
                AnimationFrame = 0;

                if (PNGTuby.Container.MouthOpen == false)
                {
                    CharacterImage.Image = Image.FromFile("../Images/" + PNGTuby.Container.Expression + "/_.png");
                }
                else
                {
                    CharacterImage.Image = Image.FromFile("../Images/" + PNGTuby.Container.Expression + "/0.png");
                }
            }
            else if (PNGTuby.Container.ImageHasAnimation[PNGTuby.Container.Expression] == true && PNGTuby.Container.MouthOpen == true)
            {
                CharacterImage.Image = Image.FromFile("../Images/" + PNGTuby.Container.Expression + "/" + AnimationFrame + ".png");

                if (AnimationFrame < PNGTuby.Container.ImageCount[PNGTuby.Container.Expression] - 1)
                {
                    AnimationFrame++;
                }
                else
                {
                    AnimationFrame = 0;
                }
            }
        }



        //----------------------------------------------------------------------------------------------------------------
        //buttons and such -----------------------------------------------------------------------------------------------
        //----------------------------------------------------------------------------------------------------------------

        //expression buttons
        private void Neutral_Click(object sender, EventArgs e)
        {
            PNGTuby.Container.Expression = 0;
            label2.Text = ": |  - Neutral";
        }

        private void Happy_Click(object sender, EventArgs e)
        {
            PNGTuby.Container.Expression = 1;
            label2.Text = ": )  - Happy";
        }

        private void VeryHappy_Click(object sender, EventArgs e)
        {
            PNGTuby.Container.Expression = 2;
            label2.Text = ": D  - Extatic";
        }

        private void Angry_Click(object sender, EventArgs e)
        {
            PNGTuby.Container.Expression = 3;
            label2.Text = ">: D - Angry";
        }

        private void Shocked_Click(object sender, EventArgs e)
        {
            PNGTuby.Container.Expression = 4;
            label2.Text = ": O  - Shocked";
        }

        private void Sad_Click(object sender, EventArgs e)
        {
            PNGTuby.Container.Expression = 5;
            label2.Text = ": (  - Sad";
        }

        private void label2_Click(object sender, EventArgs e)
        {
            
        }

        private void CharachterImage_Click(object sender, EventArgs e)
        {

        }


        //-------------------------------------------------------------------------------------------------


        //Keybind buttons
        private void KeyBind1_Click(object sender, EventArgs e)
        {
            if (PNGTuby.Container.KeyBindButtonPressed == -1)
            {
                PNGTuby.Container.KeyBindButtonPressed = 1;
                KeyBind1.Text = "Select a key";

                RegisterKeys();
            }
        }

        private void KeyBind2_Click(object sender, EventArgs e)
        {
            if (PNGTuby.Container.KeyBindButtonPressed == -1)
            {
                PNGTuby.Container.KeyBindButtonPressed = 2;
                KeyBind2.Text = "Select a key";

                RegisterKeys();
            }
        }

        private void KeyBind3_Click(object sender, EventArgs e)
        {
            if (PNGTuby.Container.KeyBindButtonPressed == -1)
            {
                PNGTuby.Container.KeyBindButtonPressed = 3;
                KeyBind3.Text = "Select a key";

                RegisterKeys();
            }
        }

        private void KeyBind4_Click(object sender, EventArgs e)
        {
            if (PNGTuby.Container.KeyBindButtonPressed == -1)
            {
                PNGTuby.Container.KeyBindButtonPressed = 4;
                KeyBind4.Text = "Select a key";

                RegisterKeys();
            }
        }

        private void Keybind5_Click(object sender, EventArgs e)
        {
            if (PNGTuby.Container.KeyBindButtonPressed == -1)
            {
                PNGTuby.Container.KeyBindButtonPressed = 5;
                Keybind5.Text = "Select a key";

                RegisterKeys();
            }
        }

        private void KeyBind6_Click(object sender, EventArgs e)
        {
            if (PNGTuby.Container.KeyBindButtonPressed == -1)
            {
                PNGTuby.Container.KeyBindButtonPressed = 6;
                KeyBind6.Text = "Select a key";

                RegisterKeys();
            }
        }

        private void KeyBindGreenscreen_Click(object sender, EventArgs e)
        {
            if (PNGTuby.Container.KeyBindButtonPressed == -1)
            {
                PNGTuby.Container.KeyBindButtonPressed = 0;
                KeyBind0.Text = "Select a key";

                RegisterKeys();
            }
        }


        //-------------------------------------------------------------------------------------------------


        //change UpdateTime when the slider is moved
        private void UpdateSetBar_ValueChanged(object sender, EventArgs e)
        {
            PNGTuby.Container.UpdateTime = ((UpdateSetBar.Value + 10) * 2);
            UpdateSetLabel.Text = ("per " + PNGTuby.Container.UpdateTime.ToString() + " ticks");
            timer.Interval = PNGTuby.Container.UpdateTime;
        }

        //only change the chromakey background colour when a different member is selected
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (comboBox1.SelectedItem)
            {
                case "Magenta":
                    if (CharacterImage.BackColor != Color.Magenta)
                    {
                        CharacterImage.BackColor = Color.Magenta;
                        PNGTuby.Container.BackColor = Color.Magenta;
                    }

                    break;

                case "Cyan":
                    if (CharacterImage.BackColor != Color.Cyan)
                    {
                        CharacterImage.BackColor = Color.Cyan;
                        PNGTuby.Container.BackColor = Color.Cyan;
                    }

                    break;

                default:
                    if (CharacterImage.BackColor != Color.Lime)
                    {
                        CharacterImage.BackColor = Color.Lime;
                        PNGTuby.Container.BackColor = Color.Lime;
                    }

                    break;
            }
        }

        private void VolumeTrack_ValueChanged(object sender, EventArgs e)
        {
            PNGTuby.Container.VolumeCompare = VolumeTrack.Value;
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
            {
                PNGTuby.Container.GreenScreenOn = true;
            }
            else
            {
                PNGTuby.Container.GreenScreenOn = false;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            PNGTuby.Container.Exit = false;
            Close();
        }
    }
}
