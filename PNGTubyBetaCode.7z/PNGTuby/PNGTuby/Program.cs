﻿using System;
using System.IO;
using System.Windows.Forms;

namespace PNGTuby
{
    

    static class Program
    {        
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]

        static void Main()
        {
            //
            //pre-form image inventorisation
            //
            Container.Exit = false;

            //check whether /Images/ exists
            if (Directory.Exists("../Images/") == false)
            {
                Directory.CreateDirectory("../Images/");

                for (int i = 0; i < 6; i++)
                {
                    Directory.CreateDirectory("../Images/" + i + "/");
                    Directory.CreateDirectory("../Images/Background" + i + "/");
                }

                Container.Exit = true;
            }
            //check whether the subfolders exist
            else for (int i = 0; i < 6; i++)
            {
                if (Directory.Exists("../Images/" + i + "/") == false)
                {
                    Directory.CreateDirectory("../Images/" + i + "/");

                    Container.Exit = true;
                }
                if (Directory.Exists("../Images/Background" + i + "/") == false)
                {
                    Directory.CreateDirectory("../Images/Background" + i + "/");

                    Container.Exit = true;
                }
            }
            if (Container.Exit == true)
            {
                MessageBox.Show("Some necessary folders did not exist.\nCreating folders and closing application.\nPlease refer to the documentation for further details.");
            }

            //check whether there's any empty folders
            if (Container.Exit == false)
            {
                bool NoImages = false;

                //check whether a generic background image is present
                if (File.Exists("../Images/Background.png") == false)
                {
                    NoImages = true;
                }
                //if there is, check the subfolders to see whether there's an empty one
                else for (int i = 0; i < 6; i++)
                {
                    PNGTuby.Container.ImageCount[i] = 0;

                    while (PNGTuby.Container.ImageCountReached[i] == false)
                    {
                        if (File.Exists("../Images/" + i + "/" + PNGTuby.Container.ImageCount[i] + ".png") == false)
                        {
                            PNGTuby.Container.ImageCountReached[i] = true;

                            break;
                        }
                        PNGTuby.Container.ImageCount[i]++;
                    }

                    if (PNGTuby.Container.ImageCount[i] == 0)
                    {
                        NoImages = true;
                    }
                    else if (PNGTuby.Container.ImageCount[i] > 1)
                    {
                        PNGTuby.Container.ImageHasAnimation[i] = true;
                    }

                    if (File.Exists("../Images/" + i + "/_.png") == false)
                    {
                        NoImages = true;
                    }
                }

                if (NoImages == true)
                {
                    MessageBox.Show("Not every expression folder contains images or they may not be properly labelled.\nPlease refer to the documentation for further details.");
                    Container.Exit = true;
                }
            }

            if (Container.Exit == false)
            {
                //check for empty
                for (int i = 0; i < 6; i++)
                {
                    PNGTuby.Container.BackImageCount[i] = 0;

                    while (PNGTuby.Container.BackImageCountReached[i] == false)
                    {
                        if (File.Exists("../Images/Background" + i + "/" + PNGTuby.Container.BackImageCount[i] + ".png") == false)
                        {
                            PNGTuby.Container.BackImageCountReached[i] = true;
                            break;
                        }
                        PNGTuby.Container.BackImageCount[i]++;
                    }

                    if (PNGTuby.Container.BackImageCount[i] > 0)
                    {
                        PNGTuby.Container.BackImageHasCustom[i] = true;

                        if (PNGTuby.Container.BackImageCount[i] > 1)
                        {
                            PNGTuby.Container.BackImageHasAnimation[i] = true;
                        }
                    }
                }

                //
                //initialize forms
                //
                Container.Exit = true;

                Application.Run(new Form1());

                while (Container.Exit == false)
                {
                    Application.Run(new Form3());

                    Container.Exit = true;
                    Application.Run(new Form1());
                }
            }
        }
    }
}
