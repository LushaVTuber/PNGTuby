﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace PNGTuby
{
    public partial class Form2 : Form
    {

        //initialize local image variables
        public static int AnimationFrame = 0;
        public static int LastExpression = 0;
        public static bool LastTalkingState = false;

        public static int BackgroundAnimationFrame = 0;


        public Form2()
        {
            InitializeComponent();

            //Application.Run(new Form2());
            //CharacterImage.Image = Image.FromFile("../Images/0.png");
            if (PNGTuby.Container.GreenScreenOn == true)
            {
                CharacterImage.BackColor = PNGTuby.Container.BackColor;
                CharacterImage.BackgroundImage = null;
            }
            else
            {
                if (PNGTuby.Container.BackImageHasCustom[PNGTuby.Container.Expression] == true)
                {
                    CharacterImage.BackgroundImage = Image.FromFile("../Images/Background" + PNGTuby.Container.Expression + "/0.png");
                }
                else
                {
                    CharacterImage.BackgroundImage = Image.FromFile("../Images/Background.png");
                }
            }
            
            CharacterImage.BackgroundImage = Image.FromFile("../Images/Background.png");
            CharacterImage.Image = Image.FromFile("../Images/" + PNGTuby.Container.Expression.ToString() + "/_.png");

            //timer stuff
            timer.Interval = PNGTuby.Container.UpdateTime;
            timer.Start();

            timer.Tick += Timer_Tick;

            //start things
            timer.Start();
        }


        //----------------------------------------------------------------------------------------------------------------
        //Ths portion of the code handles setting keybinds (when the flag for it is set), as well as responding to pressed keybinds
        //----------------------------------------------------------------------------------------------------------------
        protected override void WndProc(ref Message m)
        {

            // Catch when a HotKey is pressed
            if (m.Msg == 0x0312)
            {
                int id = m.WParam.ToInt32();


                if (id == PNGTuby.Container.KeyBinds[0])
                {
                    if (PNGTuby.Container.GreenScreenOn == false)
                    {
                        PNGTuby.Container.GreenScreenOn = true;
                    }
                    else
                    {
                        PNGTuby.Container.GreenScreenOn = false;
                    }
                }
                else if (id == PNGTuby.Container.KeyBinds[1])
                {
                    PNGTuby.Container.Expression = 1;
                }
                else if (id == PNGTuby.Container.KeyBinds[2])
                {
                    PNGTuby.Container.Expression = 2;
                }
                else if (id == PNGTuby.Container.KeyBinds[3])
                {
                    PNGTuby.Container.Expression = 3;
                }
                else if (id == PNGTuby.Container.KeyBinds[4])
                {
                    PNGTuby.Container.Expression = 4;
                }
                else if (id == PNGTuby.Container.KeyBinds[5])
                {
                    PNGTuby.Container.Expression = 5;
                }
                else if (id == PNGTuby.Container.KeyBinds[6])
                {
                    PNGTuby.Container.Expression = 6;
                }
            }

            base.WndProc(ref m);
        }


        //----------------------------------------------------------------------------------------------------------------
        //Timer stuff ----------------------------------------------------------------------------------------------------
        //----------------------------------------------------------------------------------------------------------------
        public void Timer_Tick(object sender, EventArgs e)
        {

            //reset LastTalkState
            LastTalkingState = PNGTuby.Container.MouthOpen;

            //check mic selection and set volume
            if (PNGTuby.Container.SoundInputDevice != null)
            {
                PNGTuby.Container.Volume = (int)(PNGTuby.Container.SoundInputDevice.AudioMeterInformation.MasterPeakValue * 100);
            }


            //-------------------------------------------------------------------------------------------------


            //check talking state
            if (PNGTuby.Container.Volume > PNGTuby.Container.VolumeCompare)
            {
                PNGTuby.Container.MouthOpen = true;
            }
            else
            {
                PNGTuby.Container.MouthOpen = false;
            }


            //-------------------------------------------------------------------------------------------------


            //update the background image, if necessary
            if (PNGTuby.Container.GreenScreenOn == true)
            {
                CharacterImage.BackgroundImage = null;
            }
            else
            {
                if (PNGTuby.Container.Expression != LastExpression || CharacterImage.BackgroundImage == null)
                {
                    //reset BackgroundAnimationFrame
                    BackgroundAnimationFrame = 0;

                    if (PNGTuby.Container.BackImageHasCustom[PNGTuby.Container.Expression] == true)
                    {
                        CharacterImage.BackgroundImage = Image.FromFile("../Images/Background.png");
                    }
                    else
                    {
                        CharacterImage.BackgroundImage = Image.FromFile("../Images/Background.png");
                    }
                }
                else if (PNGTuby.Container.BackImageHasAnimation[PNGTuby.Container.Expression] == true)
                {
                    CharacterImage.BackgroundImage = Image.FromFile("../Images/Background" + PNGTuby.Container.Expression + "/" + BackgroundAnimationFrame + ".png");

                    if (BackgroundAnimationFrame < PNGTuby.Container.BackImageCount[PNGTuby.Container.Expression] - 1)
                    {
                        BackgroundAnimationFrame++;
                    }
                    else
                    {
                        BackgroundAnimationFrame = 0;
                    }
                }
            }


            //-------------------------------------------------------------------------------------------------


            //update CharacterImage, if necessary
            if (PNGTuby.Container.Expression != LastExpression || PNGTuby.Container.MouthOpen != LastTalkingState)
            {
                //reset LastExpression and AnimationFrame
                LastExpression = PNGTuby.Container.Expression;
                AnimationFrame = 0;

                if (PNGTuby.Container.MouthOpen == false)
                {
                    CharacterImage.Image = Image.FromFile("../Images/" + PNGTuby.Container.Expression + "/_.png");
                }
                else
                {
                    CharacterImage.Image = Image.FromFile("../Images/" + PNGTuby.Container.Expression + "/0.png");
                }
            }
            else if (PNGTuby.Container.ImageHasAnimation[PNGTuby.Container.Expression] == true && PNGTuby.Container.MouthOpen == true)
            {
                CharacterImage.Image = Image.FromFile("../Images/" + PNGTuby.Container.Expression + "/" + AnimationFrame + ".png");

                if (AnimationFrame < PNGTuby.Container.ImageCount[PNGTuby.Container.Expression] - 1)
                {
                    AnimationFrame++;
                }
                else
                {
                    AnimationFrame = 0;
                }
            }
        }
    }
}

