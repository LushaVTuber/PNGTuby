﻿
namespace PNGTuby
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.CharacterImage = new System.Windows.Forms.PictureBox();
            this.timer = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.CharacterImage)).BeginInit();
            this.SuspendLayout();
            // 
            // CharacterImage
            // 
            this.CharacterImage.Location = new System.Drawing.Point(2, 1);
            this.CharacterImage.Name = "CharacterImage";
            this.CharacterImage.Size = new System.Drawing.Size(640, 640);
            this.CharacterImage.TabIndex = 0;
            this.CharacterImage.TabStop = false;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(644, 642);
            this.Controls.Add(this.CharacterImage);
            this.Cursor = System.Windows.Forms.Cursors.Default;
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Name = "Form2";
            this.Opacity = 0D;
            this.Text = "Form2";
            ((System.ComponentModel.ISupportInitialize)(this.CharacterImage)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        public System.Windows.Forms.PictureBox CharacterImage;
        private System.Windows.Forms.Timer timer;
    }
}