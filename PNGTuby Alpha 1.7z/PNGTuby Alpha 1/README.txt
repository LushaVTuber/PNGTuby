Thank you for choosing this program over our (probably) non-existant competition!
This alpha version is a prototype of sorts. It's functional, but barebones.
Feedback is much-appreciated!
Still, it works! Here's how:

There's two subfolders:
   1. Files
This contains all the code stuff, as well as the actual program.
To start the program, fire up the one called PNGTuby. Not .exe or anything (although admittably that is confusing).
It's the one that says "Application" in a column to its right.

   2. Images
This one just contains the images. Straightforward, huh?
You wanna replace these with your own expressions, using the same names.
Oh and pick a nice background! 
Transparency is allowed, but only for the foreground image (ya face).

IMPORTANT:  Right now, it ONLY SUPPORTS 640x640 pixel images.
It'll look like shit if you use the wrong size.

   For use in OBS:
You can capture the window in OBS; it won't show a window border. Just the background and your face.
Well, that and the buttons, so keep that part below the OBS feed!


Again, it's not perfect. I did it in only two days, okay!!?!
Ahem.
Please, if you have any suggestions, DM them to me :)
And share the news about this tool if you deem it worthy!