﻿
namespace PNGTuby
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.veryhappy = new System.Windows.Forms.Button();
            this.neutral = new System.Windows.Forms.Button();
            this.happy = new System.Windows.Forms.Button();
            this.angry = new System.Windows.Forms.Button();
            this.shocked = new System.Windows.Forms.Button();
            this.sad = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.CharacterImage = new System.Windows.Forms.PictureBox();
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.label3 = new System.Windows.Forms.Label();
            this.VolumeBar = new System.Windows.Forms.ProgressBar();
            this.label4 = new System.Windows.Forms.Label();
            this.VolumeTrack = new System.Windows.Forms.TrackBar();
            this.label5 = new System.Windows.Forms.Label();
            this.DeviceBox = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.CharacterImage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.VolumeTrack)).BeginInit();
            this.SuspendLayout();
            // 
            // veryhappy
            // 
            this.veryhappy.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.veryhappy.Location = new System.Drawing.Point(444, 798);
            this.veryhappy.Name = "veryhappy";
            this.veryhappy.Size = new System.Drawing.Size(182, 121);
            this.veryhappy.TabIndex = 7;
            this.veryhappy.Text = ": D";
            this.veryhappy.UseVisualStyleBackColor = true;
            this.veryhappy.Click += new System.EventHandler(this.VeryHappy_Click);
            // 
            // neutral
            // 
            this.neutral.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.neutral.Location = new System.Drawing.Point(12, 798);
            this.neutral.Name = "neutral";
            this.neutral.Size = new System.Drawing.Size(182, 121);
            this.neutral.TabIndex = 8;
            this.neutral.Text = ": |";
            this.neutral.UseVisualStyleBackColor = true;
            this.neutral.Click += new System.EventHandler(this.Neutral_Click);
            // 
            // happy
            // 
            this.happy.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.happy.Location = new System.Drawing.Point(229, 798);
            this.happy.Name = "happy";
            this.happy.Size = new System.Drawing.Size(182, 121);
            this.happy.TabIndex = 9;
            this.happy.Text = ": )";
            this.happy.UseVisualStyleBackColor = true;
            this.happy.Click += new System.EventHandler(this.Happy_Click);
            // 
            // angry
            // 
            this.angry.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.angry.Location = new System.Drawing.Point(12, 929);
            this.angry.Name = "angry";
            this.angry.Size = new System.Drawing.Size(182, 121);
            this.angry.TabIndex = 10;
            this.angry.Text = ">: D";
            this.angry.UseVisualStyleBackColor = true;
            this.angry.Click += new System.EventHandler(this.Angry_Click);
            // 
            // shocked
            // 
            this.shocked.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.shocked.Location = new System.Drawing.Point(229, 929);
            this.shocked.Name = "shocked";
            this.shocked.Size = new System.Drawing.Size(182, 121);
            this.shocked.TabIndex = 11;
            this.shocked.Text = ": O";
            this.shocked.UseVisualStyleBackColor = true;
            this.shocked.Click += new System.EventHandler(this.Shocked_Click);
            // 
            // sad
            // 
            this.sad.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sad.Location = new System.Drawing.Point(444, 929);
            this.sad.Name = "sad";
            this.sad.Size = new System.Drawing.Size(182, 121);
            this.sad.TabIndex = 12;
            this.sad.Text = ": (";
            this.sad.UseVisualStyleBackColor = true;
            this.sad.Click += new System.EventHandler(this.Sad_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(5, 643);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(216, 31);
            this.label1.TabIndex = 13;
            this.label1.Text = "Current emotion:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(268, 643);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(154, 31);
            this.label2.TabIndex = 14;
            this.label2.Text = ": |  - Neutral";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // CharacterImage
            // 
            this.CharacterImage.Location = new System.Drawing.Point(-1, 0);
            this.CharacterImage.Name = "CharacterImage";
            this.CharacterImage.Size = new System.Drawing.Size(640, 640);
            this.CharacterImage.TabIndex = 16;
            this.CharacterImage.TabStop = false;
            this.CharacterImage.Click += new System.EventHandler(this.CharachterImage_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(5, 717);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(207, 31);
            this.label3.TabIndex = 17;
            this.label3.Text = "Current volume:";
            // 
            // VolumeBar
            // 
            this.VolumeBar.Location = new System.Drawing.Point(274, 725);
            this.VolumeBar.Name = "VolumeBar";
            this.VolumeBar.Size = new System.Drawing.Size(327, 19);
            this.VolumeBar.TabIndex = 19;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(5, 680);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(232, 31);
            this.label4.TabIndex = 20;
            this.label4.Text = "Recording device:";
            // 
            // VolumeTrack
            // 
            this.VolumeTrack.LargeChange = 10;
            this.VolumeTrack.Location = new System.Drawing.Point(262, 754);
            this.VolumeTrack.Maximum = 100;
            this.VolumeTrack.Name = "VolumeTrack";
            this.VolumeTrack.Size = new System.Drawing.Size(349, 45);
            this.VolumeTrack.SmallChange = 5;
            this.VolumeTrack.TabIndex = 21;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(5, 754);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(188, 31);
            this.label5.TabIndex = 22;
            this.label5.Text = "Vol. threshold:";
            // 
            // DeviceBox
            // 
            this.DeviceBox.FormattingEnabled = true;
            this.DeviceBox.Location = new System.Drawing.Point(274, 690);
            this.DeviceBox.Name = "DeviceBox";
            this.DeviceBox.Size = new System.Drawing.Size(327, 21);
            this.DeviceBox.TabIndex = 23;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(638, 1062);
            this.Controls.Add(this.DeviceBox);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.VolumeTrack);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.VolumeBar);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.CharacterImage);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.sad);
            this.Controls.Add(this.shocked);
            this.Controls.Add(this.angry);
            this.Controls.Add(this.happy);
            this.Controls.Add(this.neutral);
            this.Controls.Add(this.veryhappy);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.CharacterImage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.VolumeTrack)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button veryhappy;
        private System.Windows.Forms.Button neutral;
        private System.Windows.Forms.Button happy;
        private System.Windows.Forms.Button angry;
        private System.Windows.Forms.Button shocked;
        private System.Windows.Forms.Button sad;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        public System.Windows.Forms.PictureBox CharacterImage;
        private System.Windows.Forms.Timer timer;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ProgressBar VolumeBar;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TrackBar VolumeTrack;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox DeviceBox;
    }
}

