﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PNGTuby
{
    class Container
    {
        public static int Expression = 0;
        public static string MouthOpen = "";
        public static int Volume = 0;
    }
}
