﻿using System;
using System.Linq;
using System.Windows.Forms;
using System.Drawing;
using NAudio.CoreAudioApi;

namespace PNGTuby
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            //Application.Run(new Form2());
            CharacterImage.Image = Image.FromFile("../Images/0.png");
            CharacterImage.BackgroundImage = Image.FromFile("../Images/Background.png");


            //setting up the audio shizz
            MMDeviceEnumerator en = new MMDeviceEnumerator();
            var devices = en.EnumerateAudioEndPoints(DataFlow.All, DeviceState.Active);
            DeviceBox.Items.AddRange(devices.ToArray());

            //timer stuff
            timer.Interval = 50;
            timer.Start();

            timer.Tick += Timer_Tick;

            //start things
            timer.Start();
        }

        public void Timer_Tick(object sender, EventArgs e)
        {
            //check mic selection and set volume
            if (DeviceBox.SelectedItem != null)
            {
                var SingleDevice = (MMDevice)DeviceBox.SelectedItem;
                PNGTuby.Container.Volume = (int)(SingleDevice.AudioMeterInformation.MasterPeakValue * 100);

                VolumeBar.Value = PNGTuby.Container.Volume;
            }

            //check talking state
            if (PNGTuby.Container.Volume > VolumeTrack.Value)
            {
                PNGTuby.Container.MouthOpen = "_";
            }
            else
            {
                PNGTuby.Container.MouthOpen = "";
            }

            //update CharacterImage
            CharacterImage.Image = Image.FromFile("../Images/" + PNGTuby.Container.Expression + PNGTuby.Container.MouthOpen + ".png");
        }

        private void Neutral_Click(object sender, EventArgs e)
        {
            PNGTuby.Container.Expression = 0;
            label2.Text = ": |  - Neutral";
        }

        private void Happy_Click(object sender, EventArgs e)
        {
            PNGTuby.Container.Expression = 1;
            label2.Text = ": )  - Happy";
        }

        private void VeryHappy_Click(object sender, EventArgs e)
        {
            PNGTuby.Container.Expression = 2;
            label2.Text = ": D  - Extatic";
        }

        private void Angry_Click(object sender, EventArgs e)
        {
            PNGTuby.Container.Expression = 3;
            label2.Text = ">: D - Angry";
        }

        private void Shocked_Click(object sender, EventArgs e)
        {
            PNGTuby.Container.Expression = 4;
            label2.Text = ": O  - Shocked";
        }

        private void Sad_Click(object sender, EventArgs e)
        {
            PNGTuby.Container.Expression = 5;
            label2.Text = ": (  - Sad";
        }

        private void label2_Click(object sender, EventArgs e)
        {
            
        }

        private void CharachterImage_Click(object sender, EventArgs e)
        {

        }
    }
}
